#!/bin/bash
## Script that uses the metassemble.py wrapper to metassemble assembly A and B, using
## assembly A as the primary assembly, and a 2kb mate-pair simulated library.

METAPATH="/home/manuel/assembly_rec/Metassembler/"

METHODNAME1=megahit
CONTIGFILE1=$(pwd)/contigs/escherichia_coli_megahit_contigs.fasta

METHODNAME2=minia
CONTIGFILE2=$(pwd)/contigs/escherichia_coli_minia_contigs.fasta

METHODNAME3=spades
CONTIGFILE3=$(pwd)/contigs/escherichia_coli_spades_contigs.fasta

METHODNAME4=velvet
CONTIGFILE4=$(pwd)/contigs/escherichia_coli_velvet_contigs.fasta


CFGFILENAME=$METHODNAME4.$METHODNAME3.$METHODNAME2.$METHODNAME1.metassemble.config

### Generate configuration file that will be input for metassemble.py
echo -e "\
############################################\n\
###   Metassemble A and B configuration file\n\
############################################\n\
[global]\n\
\n\
bowtie2_threads=1\n\
bowtie2_read1=$(pwd)/reads/escherichia_coli_SRR13921546.1_1.fastq\n\
bowtie2_read2=$(pwd)/reads/escherichia_coli_SRR13921546.1_2.fastq\n\
bowtie2_maxins=3000\n\
bowtie2_minins=1000\n\
\n\

\n\
mateAn_A=1300\n\
mateAn_B=2300\n\
\n\
[1]\n\
\n\
fasta=$CONTIGFILE1\n\
ID=$METHODNAME1\n\
\n\
[2]\n\
\n\
fasta=$CONTIGFILE2\n\
ID=$METHODNAME2\n\
\n\
[3]\n\
\n\
fasta=$CONTIGFILE3\n\
ID=$METHODNAME3\n\
\n\
[4]\n\
\n\
fasta=$CONTIGFILE4\n\
ID=$METHODNAME4\n\
" > $METHODNAME4.$METHODNAME3.$METHODNAME2.$METHODNAME1.metassemble.config

### Run metassemble
$METAPATH/bin/metassemble --conf $CFGFILENAME --outd ./MergeMetassemble  

mv $CFGFILENAME ./MergeMetassemble
